// ============================================================
// src/components/Board/Board.tsx
//
// PURPOSE: Renders the game grid as a CSS Grid layout.
// Each cell is interactive — clicking selects a figure or applies a move.
//
// This is a "dumb" (presentational) component — it receives all data
// via props and fires events upward. It never reads from the store directly.
// This makes it easy to test in isolation and reuse with different state layers.
//
// The 'use client' directive is required because this component uses
// browser events (onClick). Without it, Next.js would try to render
// it on the server where event handlers don't exist.
// ============================================================

'use client';

import React from 'react';
import type { Position, PlayerFigureInstance, Level } from '../../domain/types';
import { getFigureAt } from '../../domain/board';
import { FigureIcon } from '../figures/FigureIcon';
import styles from './Board.module.css';

// ── Props ─────────────────────────────────────────────────────

interface BoardProps {
  /** Level definition — provides boardWidth and boardHeight. */
  level: Level;
  /** All figure instances in the game (placed and unplaced). */
  figures: PlayerFigureInstance[];
  /** Maps each playerId to its CSS color string — used to color tokens by owner. */
  playerColors: Record<string, string>;
  /** Side length of each cell in pixels — computed by GameCanvas via ResizeObserver. */
  cellSize?: number;
  /** The instanceId of the currently selected figure, or null if none. */
  selectedInstanceId: string | null;
  /** Squares highlighted as valid destinations for the selected figure. */
  validMoveTargets: Position[];
  /** Called when the user clicks an empty cell (or a highlighted target). */
  onCellClick: (pos: Position) => void;
  /** Called when the user clicks a placed figure on the board. */
  onFigureClick: (instanceId: string) => void;
}

// ── Board component ───────────────────────────────────────────

/**
 * Board renders the full game grid.
 *
 * Inputs:  see BoardProps above
 * Outputs: fires onCellClick or onFigureClick callbacks
 * Side effects: none — purely visual
 */
export function Board({
  level,
  figures,
  playerColors,
  cellSize = 64,
  selectedInstanceId,
  validMoveTargets,
  onCellClick,
  onFigureClick,
}: BoardProps) {
  const { boardWidth, boardHeight } = level;

  // Convert the validMoveTargets array to a Set of "col,row" strings.
  // Set.has() is O(1) — faster than scanning an array for every cell.
  const targetSet = new Set(validMoveTargets.map((p) => `${p.col},${p.row}`));
  // Map from column → exact winning Position for top zone (row < 0)
  const topWinByCol = new Map<number, Position>();
  // Map from column → exact winning Position for bottom zone (row >= boardHeight)
  const bottomWinByCol = new Map<number, Position>();

  for (const pos of validMoveTargets) {
    if (pos.row < 0) topWinByCol.set(pos.col, pos);
    if (pos.row >= boardHeight) bottomWinByCol.set(pos.col, pos);
  }
  
  const cells: React.ReactNode[] = [];

  // Build cells row by row, column by column (top-left to bottom-right).
  for (let row = 0; row < boardHeight; row++) {
    for (let col = 0; col < boardWidth; col++) {
      const posKey = `${col},${row}`;
      const figure = getFigureAt(col, row, figures);
      const isHighlighted = targetSet.has(posKey);
      const isSelected = figure !== null && figure.instanceId === selectedInstanceId;

      // Checkerboard pattern: light when (row + col) is even.
      const isLight = (row + col) % 2 === 0;

      cells.push(
        <div
          key={posKey}
          className={[
            styles.cell,
            isLight ? styles.cellLight : styles.cellDark,
            isHighlighted ? styles.cellHighlighted : '',
            isSelected ? styles.cellSelected : '',
          ]
            .filter(Boolean)
            .join(' ')}
          onClick={() => {
            if (figure && !isHighlighted) {
              // Clicked a piece — delegate to parent for selection logic.
              onFigureClick(figure.instanceId);
            } else {
              // Clicked an empty square — may be a move/place target.
              onCellClick({ col, row });
            }
          }}
        >
          {figure && (
            <FigureToken
              instance={figure}
              isSelected={isSelected}
              color={playerColors[figure.playerId] ?? '#888'}
              iconSize={Math.max(16, cellSize - 6)}
            />
          )}
        </div>,
      );
    }
  }

  // Build finish zone rows — one cell per column, clickable only when a
  // winning move lands in that column.
  const topZone = Array.from({ length: boardWidth }, (_, col) => {
    const winPos = topWinByCol.get(col);
    return (
      <div
        key={`top-finish-${col}`}
        className={[styles.finishCell, winPos ? styles.cellWinTarget : '']
          .filter(Boolean)
          .join(' ')}
        onClick={() => winPos && onCellClick(winPos)}
      />
    );
  });

  const bottomZone = Array.from({ length: boardWidth }, (_, col) => {
    const winPos = bottomWinByCol.get(col);
    return (
      <div
        key={`bottom-finish-${col}`}
        className={[styles.finishCell, winPos ? styles.cellWinTarget : '']
          .filter(Boolean)
          .join(' ')}
        onClick={() => winPos && onCellClick(winPos)}
      />
    );
  });

  return (
    <div
      className={styles.boardOuter}
      // --cell-size is consumed by .cell and .finishCell in Board.module.css
      style={{ '--cell-size': `${cellSize}px` } as React.CSSProperties}
    >
      {/* Top finish zone — Player 1 (bottom player) wins by crossing here */}
      <div
        className={styles.finishZone}
        style={{
          gridTemplateColumns: `repeat(${boardWidth}, 1fr)`,
          backgroundColor: level.player1Color,
        }}
        title={`${level.player1Color} goal`}
      >
        {topZone}
      </div>

      {/* Main board grid */}
      <div
        className={styles.board}
        style={{
          gridTemplateColumns: `repeat(${boardWidth}, 1fr)`,
          gridTemplateRows: `repeat(${boardHeight}, 1fr)`,
        }}
      >
        {cells}
      </div>

      {/* Bottom finish zone — Player 2 (top player) wins by crossing here */}
      <div
        className={styles.finishZone}
        style={{
          gridTemplateColumns: `repeat(${boardWidth}, 1fr)`,
          backgroundColor: level.player2Color,
        }}
        title={`${level.player2Color} goal`}
      >
        {bottomZone}
      </div>
    </div>
  );
}

// ── Sub-component: FigureToken ────────────────────────────────

interface FigureTokenProps {
  instance: PlayerFigureInstance;
  isSelected: boolean;
  /** Owner's player color — stable for the lifetime of the piece. */
  color: string;
  /** SVG icon diameter in px — scales with cell size. */
  iconSize: number;
}

/**
 * FigureToken renders a single piece on the board using the SVG FigureIcon.
 *
 * Inputs:  instance, isSelected, color, iconSize
 * Outputs: none (purely visual)
 * Side effects: none
 */
function FigureToken({ instance, isSelected, color, iconSize }: FigureTokenProps) {
  return (
    <FigureIcon
      figureTypeId={instance.figureTypeId}
      color={color}
      size={iconSize}
      selected={isSelected}
    />
  );
}
